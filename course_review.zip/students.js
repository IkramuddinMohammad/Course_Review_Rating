const students = [
    { 
      _id: "0", 
      email: "donald@stevens.edu", 
      hashedPassword: "$2a$16$55b4ftaRCsHZcJ2X3VAmL.X85wi/K3ydOMWRoyafn2ubiA38l4HnK", 
      firstName: "Donald", 
      lastName: "Brown"
    }, 
    { 
      _id: "1", 
      email: "michael@stevens.edu",  
      hashedPassword: "$2a$16$r1Og9JVorymlohw46G5f2eWnmApVjfEESW5ypQx8bpwGPrZwx5ED.", 
      firstName: "Michael", 
      lastName: "Trump",
    },
    { 
      _id: "2", 
      email: "kartik@stevens.edu",  
      hashedPassword: "$2a$16$0VqDgHHXpug/TGMH2pcMRub7jvOzHrT18Uk6ll44U.OActZ0HVzLC", 
      firstName: "Kartik", 
      lastName: "Shah",
    }
]

module.exports = { students };